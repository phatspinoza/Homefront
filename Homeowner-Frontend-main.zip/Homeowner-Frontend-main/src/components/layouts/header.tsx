import { useState, useRef, useEffect } from "react";
import ContainerLayout from "@/layouts/containerLayout";
import { Box, Button, Drawer, Flex, List, Text } from "@mantine/core";
import Image from "next/image";
import { FaBars } from "react-icons/fa";
import ButtonInterface from "../micro/buttonInterface";
import { MdOutlineClose } from "react-icons/md";
import Link from "next/link";
import { useDisclosure } from "@mantine/hooks";
import { largeView, smallView } from "@/utils/responsiveView";
import Logo from "../micro/logo";
import { useMediaQuery } from "@mantine/hooks";
import SignIn from "../popup_contents/auth_popup/signIn";
import SignUp from "../popup_contents/auth_popup/signUp";

const Header = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false); // state to track whether sidebar is open
  const sidebarRef = useRef(null);
  const isMobile = useMediaQuery("(max-width:600px)");

  useEffect(() => {
    //@ts-ignore
    function handleClickOutside(event) {
      //@ts-ignore
      if (sidebarRef.current && !sidebarRef.current.contains(event.target)) {
        setSidebarOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [sidebarRef]);
  const navs = [
    {
      title: "Home",
      path: "/",
    },
    {
      title: "About",
      path: "/about",
    },
    {
      title: "My properties",
      path: "/",
    },
    {
      title: "Buy",
      path: "/",
      submenu: [
        {
          title: "To earn",
          path: "",
        },
        {
          title: "As joint owner",
          path: "",
        },
        {
          title: "Outright purchase",
          path: "",
        },
        {
          title: "Distress deals",
          path: "",
        },
        {
          title: "Off plan",
          path: "",
        },
        {
          title: "Properties-to earn-outright-distress-joint owner",
          path: "",
        },
      ],
    },
    {
      title: "List",
      path: "/",
      submenu: [
        {
          title: "For Rent",
          path: "",
        },
        {
          title: "For Sell",
          path: "",
        },
      ],
    },

    {
      title: "Connect",
      path: "/",
      submenu: [
        {
          title: "Unlimited Power",
          path: "",
        },
        {
          title: "Unlimited Internet",
          path: "",
        },
      ],
    },

    {
      title: "Shop",
      path: "/",
      submenu: [
        {
          title: "Foodshopping",
          path: "",
        },
        {
          title: "Electronics",
          path: "",
        },
        {
          title: "Electronics",
          path: "",
        },
        {
          title: "Electronics",
          path: "",
        },
      ],
    },

    {
      title: "Home Service",
      path: "/",
      submenu: [
        {
          title: "Home cleaning",
          path: "",
        },
        {
          title: "Errands",
          path: "",
        },
        {
          title: "Painting",
          path: "",
        },
        {
          title: "Plumber",
          path: "",
        },
      ],
    },

    {
      title: "Projects",
      path: "/",
      submenu: [
        {
          title: "Ongoing Projects",
          path: "",
        },
        {
          title: "Comming Soon",
          path: "",
        },
      ],
    },

    {
      title: "Get Agent",
      path: "/",
      submenu: [
        {
          title: "Instant Agent",
          path: "",
        },
      ],
    },

    // {
    //   title: "Join homeower",
    //   path: "/",
    //   submenu: [
    //     {
    //       title: "Landloard",
    //       path: "",
    //     },
    //     {
    //       title: "For agent",
    //       path: "",
    //     },
    //     {
    //       title: "For tenant",
    //       path: "",
    //     },
    //     {
    //       title: "For professional",
    //       path: "",
    //     },
    //   ],
    // },

    {
      title: "Partner",
      path: "/",
    },
  ];

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen); // toggle sidebar state
  };

  const [hover, setHover] = useState<string>("none");

  const [opened, { open, close }] = useDisclosure(false);
  const [logged, { open: openLogin, close: closeLogin }] = useDisclosure(false);
  const [signed, { open: openSignin, close: closeSignin }] =
    useDisclosure(false);

  const sizeDrawer = isMobile ? "100%" : "100%";
  const sizeSignUpDrawer = isMobile ? "100%" : "100%";
  return (
    <>
      <Box px={"2em"}>
        <Box c={"white"}>
          <Flex align={"center"} py={"em"} justify={"space-between"}>
            <Box>
              <Logo />
            </Box>

            <Box display={{ ...largeView }}>
              {navs.map((items) => {
                return (
                  <ul key={"items"} className="home-nav">
                    <a href={items.path}>
                      <li>{items.title}</li>
                    </a>
                  </ul>
                );
              })}
            </Box>

            <Box display={{ ...largeView }}>
              <Flex align={"center"} gap={"1.2em"}>
                <Text
                  sx={{
                    cursor: "pointer",
                  }}
                  onClick={openLogin}
                  c={"#000"}
                >
                  Login
                </Text>
                <ButtonInterface onClick={openSignin}>
                  Create Account
                </ButtonInterface>
              </Flex>
            </Box>

            <Box display={{ ...smallView }}>
              <FaBars size={"1.5em"} cursor={"pointer"} />
            </Box>
          </Flex>
        </Box>
      </Box>

      {/* open login drawer */}
      <Drawer
        opened={logged}
        onClose={closeLogin}
        position="right"
        size={sizeDrawer}
        overlayProps={{ opacity: 0.5, blur: 4 }}
      >
        <Box
          w={{
            base: "100%",
            md: "80%",
            lg: "30%",
          }}
          mx={"auto"}
        >
          <SignIn />
        </Box>
      </Drawer>

      <Drawer
        opened={signed}
        onClose={closeSignin}
        position="right"
        size={sizeSignUpDrawer}
        overlayProps={{ opacity: 0.5, blur: 5 }}
      >
        <Box
          w={{
            base: "100%",
            md: "80%",
            lg: "30%",
          }}
          mx={"auto"}
        >
          <SignUp />
        </Box>
      </Drawer>

      <Drawer opened={opened} onClose={close} size={sizeDrawer}>
        <List
          display="flex"
          sx={{
            flexDirection: "column",
            listStyleType: "none",
            justifyContent: "center",
            textAlign: "left",
            padding: "8em 1em",
            gap: "2em",
          }}
        >
          {navs.map(({ title, path }) => {
            return (
              <>
                <a href={path} className={"remove-link"}>
                  <Text
                    my={"1em"}
                    sx={{
                      cursor: "pointer",
                      color: "#22005D",
                    }}
                  >
                    {title}
                  </Text>
                </a>
              </>
            );
          })}
        </List>

        <Box>
          <Flex align={"center"} direction="column" gap={"1.2em"}>
            <Text
              sx={{
                cursor: "pointer",
              }}
              onClick={openLogin}
              c={"#000"}
            >
              Login
            </Text>
            <ButtonInterface w={"100%"} onClick={openSignin}>
              Create Account
            </ButtonInterface>
          </Flex>
        </Box>
      </Drawer>
    </>
  );
};

export default Header;
