import { Box, Text, Flex } from "@mantine/core";
import { FaBed } from "react-icons/fa";

const ProductBox = () => {
  return (
    <Box
      w={{
        lg: "400px",
        base: "100%",
        md: "400px",
      }}
      style={{
        //   boxShadow: "0px 8px 16px 0px rgba(0,0,0,0.2)",
        cursor: "pointer",
      }}
    >
      <Box
        bg={"gray"}
        h={"250px"}
        style={{
          borderRadius: "10px",
        }}
      ></Box>
      <Box py={"1em"} px={"1em"}>
        <Text weight={"bold"} fz={"20px"}>
          30, 000
        </Text>

        <Text>Plot 1673 lekki epe, lagos </Text>

        <Flex
          justify={"space-between"}
          style={{
            marginTop: "1em",
          }}
        >
          <Box my={"1em"}>
            <Flex align={"center"} gap={".5em"}>
              <FaBed size={"1.5em"} />
              <Text>3</Text>
            </Flex>
            <Text>Bedrooms</Text>
          </Box>

          <Box my={"1em"}>
            <Flex align={"center"} gap={".5em"}>
              <FaBed size={"1.5em"} />
              <Text>3</Text>
            </Flex>
            <Text>Bedrooms</Text>
          </Box>

          <Box my={"1em"}>
            <Flex align={"center"} gap={".5em"}>
              <FaBed size={"1.5em"} />
              <Text>3</Text>
            </Flex>
            <Text>Bedrooms</Text>
          </Box>
        </Flex>
      </Box>
    </Box>
  );
};
export default ProductBox;
