import { Box, Flex } from "@mantine/core";
import Image from "next/image";
const Loader = () => {
  return (
    <Box
      pos={"fixed"}
      bg={"#fff"}
      top={0}
      bottom={0}
      left={0}
      right={0}
      style={{
        zIndex: "1",
      }}
    >
      <Flex justify={"center"} align={"center"} h={"100vh"} w={"100vw"}>
        <Box>
          <Image
            alt={"Logo"}
            width={200}
            height={200}
            src={
              "https://res.cloudinary.com/dhdqt4xwu/image/upload/v1681810001/homeowners/homeowner_logo_put_up-removebg-preview_1_rfs6p3.svg"
            }
          />
        </Box>
      </Flex>
    </Box>
  );
};
export default Loader;
