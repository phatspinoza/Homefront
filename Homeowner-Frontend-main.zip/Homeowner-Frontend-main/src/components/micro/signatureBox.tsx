import { Box, Flex } from "@mantine/core";

export const SignatureBox = () => {
  return (
    <Flex
      gap={"1em"}
      my={"2em"}
      style={{
        overflow: "overflow-x",
      }}
    >
      <Box
        h={"467px"}
        w={"318px"}
        bg={"#D9D9D9"}
        style={{
          borderRadius: "18px",
        }}
      ></Box>

      <Box>
        <Box
          h={"279px"}
          w={"517px"}
          bg={"#D9D9D9"}
          style={{
            borderRadius: "18px",
          }}
        ></Box>

        <Flex gap={"1em"} my={"1em"}>
          <Box
            h={"184px"}
            w={"287px"}
            bg={"#D9D9D9"}
            style={{
              borderRadius: "18px",
            }}
          ></Box>

          <Box
            h={"184px"}
            w={"216px"}
            bg={"#D9D9D9"}
            style={{
              borderRadius: "18px",
            }}
          ></Box>
        </Flex>
      </Box>

      <Box
        h={"467px"}
        w={"318px"}
        bg={"#D9D9D9"}
        style={{
          borderRadius: "18px",
        }}
      ></Box>
    </Flex>
  );
};
