import { Button } from "@mantine/core";
import { ReactNode } from "react";
import { JsxAttribute } from "typescript";

type TButton = {
  children: ReactNode;
  rounded?: string | number;
  bg?: string;
  size?: string;
  color?: string;
  w?: string | number;
  my?: string | number;
  variant?: string;
  type?: any;
  onClick?: () => void;
};

const ButtonInterface = ({
  children,
  onClick,
  bg,
  rounded,
  size,
  color,
  w,
  my,
  type,
  variant,
  ...props
}: TButton) => {
  return (
    <>
      <Button
        size={size ? size : "lg"}
        c={color ? color : ""}
        color={bg ? bg : "red"}
        radius={rounded ? rounded : "0"}
        fz={"sm"}
        onClick={onClick}
        style={{ width: w, margin: my }}
        type={type ? type : ""}
        variant={variant ? variant : "filled"}
        {...props}
      >
        {children}
      </Button>
    </>
  );
};

export default ButtonInterface;
