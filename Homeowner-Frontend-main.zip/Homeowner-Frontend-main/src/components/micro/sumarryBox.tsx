import ContainerLayout from "@/layouts/containerLayout";
import { Box, Flex, Text } from "@mantine/core";

const SummaryBox = () => {
  return (
    <ContainerLayout>
      <Flex align={"center"} wrap={"wrap"}>
        <Box
          w={{
            base: "100%",
            lg: "50%",
          }}
        >
          <Box
            w={{
              base: "100%",
              lg: "498px",
            }}
          >
            <Text
              fz={{
                md: "35px",
                lg: "40px",
                base: "25px",
              }}
              fw={"bold"}
            >
              Strategy, transactions & transformation
            </Text>
            <Text
              fz={{
                md: "35px",
                lg: "18px",
                base: "18px",
              }}
              my={"1em"}
            >
              simply dummy text of the printing and typesetting industry. Lorem
              Ipsum has been the industry standard dummy text ever since the
              1500s, when an unknown
            </Text>
          </Box>
        </Box>
        <Box
          w={{
            base: "100%",
            lg: "50%",
          }}
          bg={"gray"}
          h={{
            lg: "600px",
            base: "300px",
          }}
          style={{
            borderRadius: "18px",
          }}
        ></Box>
      </Flex>
    </ContainerLayout>
  );
};

export default SummaryBox;
