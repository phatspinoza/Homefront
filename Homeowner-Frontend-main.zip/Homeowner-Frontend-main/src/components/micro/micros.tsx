import { Button } from "@mantine/core";
import { ReactNode } from "react";
export const ButtonStruct = ({ children }: { children: ReactNode }) => {
  return <Button>Item</Button>;
};
