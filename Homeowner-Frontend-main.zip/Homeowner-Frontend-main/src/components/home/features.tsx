import ContainerLayout from "@/layouts/containerLayout";
import { Box, Flex, Text } from "@mantine/core";
import { ICardBox } from "@/types/mixedTypes";
import { ReactNode } from "react";

import {
  CoSharing,
  MarketPlace,
  CaseVector,
  OtherVector,
} from "@/components/micro/vectors";
import FeatureBox from "./featureBox";
const datas: { src: ReactNode; title: string; body: string }[] = [
  {
    src: <CoSharing />,
    title: "Pay as you stay",
    body: "Find fully furnished apartments suited to the duration of your stay, a few months or a couple of ye",
  },
  {
    src: <MarketPlace />,
    title: "Buy Properties ",
    body: "Homeowner aims to provide low-cost internet access to all Africans, enabling them to learn, earn, and make an impact regardless of location through partnerships.",
  },
  {
    src: <CaseVector />,
    title: "My Properties",
    body: "Find fully furnished apartments suited to the duration of your stay, a few months or a couple of ye",
  },

  {
    src: <OtherVector />,
    title: "Develop my Home",
    body: "Find fully furnished apartments suited to the duration of your stay, a few months or a couple of ye",
  },
  {
    src: <CaseVector />,
    title: "List Property",
    body: "Find fully furnished apartments suited to the duration of your stay, a few months or a couple of ye",
  },

  {
    src: <OtherVector />,
    title: "Home Service",
    body: "Find fully furnished apartments suited to the duration of your stay, a few months or a couple of ye",
  },
];

const Features = () => {
  return (
    <ContainerLayout>
      <Box my={"8em"}>
        <Box
          my={"5 em"}
          w={{
            base: "100%",
            lg: "50%",
          }}
        >
          <Text
            weight={"bold"}
            fz={{
              lg: "35px",
              base: "25px",
            }}
          >
            Proptech
          </Text>
        </Box>
        <Flex wrap={"wrap"} data-aos={"fade-up"} my={"4em"} gap={"1em"}>
          {datas.map(({ title, src, body }, index) => {
            return (
              //@ts-ignore
              <FeatureBox
                data-aos={"fade-up"}
                src={src}
                title={title}
                body={body}
                key={index}
              />
            );
          })}
        </Flex>
      </Box>
    </ContainerLayout>
  );
};

export default Features;
