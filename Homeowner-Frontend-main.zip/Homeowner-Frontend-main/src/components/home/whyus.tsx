import ContainerLayout from "@/layouts/containerLayout";
import { Flex, Box, Text } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
const WhyUs = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");
  return (
    <>
      <ContainerLayout>
        <Flex
          my={"6em"}
          align={"center"}
          gap={"2em"}
          direction={{
            base: "column-reverse",
            lg: "row",
          }}
          data-aos={"fade-up"}
        >
          <Box
            w={{
              base: "100%",
              lg: "55%",
            }}
            h={"450px"}
            // bg={"#fff0f6"}
            style={{
              backgroundImage:
                "url(https://res.cloudinary.com/dhdqt4xwu/image/upload/v1683112142/homeowners/Group_237785_rnv5g1.svg)",
              backgroundRepeat: "no-repeat",
              backgroundSize: !isMobile ? "cover" : "contain",
            }}
          ></Box>
          <Box
            w={{
              base: "100%",
              lg: "55%",
            }}
          >
            <Text
              weight={"bold"}
              fz={{
                lg: "53px",
                base: "25px",
              }}
            >
              Our story
            </Text>
            <Box
              my={"1em"}
              fz={{
                base: "16px",
                lg: '"18px"',
              }}
              style={{
                lineHeight: "30px",
              }}
            >
              Homeowner™ was born out of the desire to create a stress free
              solution that provides 360 degrees resources that caters to needs
              and wants that makes life comfortable and appealing using
              technology. Imagine not having to worry about your next rent,
              insurance, how your utilities will be handled, staying connected,
              having access to the best vendors from housing agents,down to your
              cleaning and transportation needs just so you can focus and live
              your goals. Our founders believe that every individual is a star
              and the more access they get to convenient living, the more
              productive they can be. It starts with Homeowner Africa™.
            </Box>
            {/* <Flex
              my={"1em"}
              align={"center"}
              style={{
                cursor: "pointer",
              }}
              c={"red"}
            >
              <Text> Explore </Text>
            </Flex> */}
          </Box>
        </Flex>
      </ContainerLayout>
    </>
  );
};

export default WhyUs;
