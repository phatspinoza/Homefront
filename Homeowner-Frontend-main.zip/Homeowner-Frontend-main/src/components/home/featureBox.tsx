import { ICardBox } from "@/types/mixedTypes";
import { Box, Text, Flex } from "@mantine/core";
import Link from "next/link";
import React, { FC } from "react";
import { HiOutlineArrowNarrowRight } from "react-icons/hi";

const FeatureBox: FC<ICardBox> = ({ src, title, body, path }) => {
  const styles = {};
  return (
    <Box
      w={{
        base: "80%",
        md: "100%",
        lg: "270px",
      }}
      px={"1em"}
      sx={{ ...styles }}
    >
      <Box my={"1em"}>
        <Box>{src}</Box>
        <Text weight={"bold"} c={"#1D1D1D"} my={"0.5em"}>
          {title}
        </Text>
        <Text c={"#1D1D1D"}>{body}</Text>
      </Box>

      <Flex
        align={"center"}
        gap={"0.5em"}
        c={"#FA3343"}
        style={{
          cursor: "pointer",
        }}
      >
        <Text>Explore</Text>
        <HiOutlineArrowNarrowRight />
      </Flex>
    </Box>
  );
};
export default FeatureBox;
