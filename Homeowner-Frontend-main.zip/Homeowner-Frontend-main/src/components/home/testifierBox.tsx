import { Box, Avatar, Text } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
const TestifierBox = () => {
  const isMobile = useMediaQuery("(max-width: 700px)");
  return (
    <>
      <Text my={"1.5em"}>
        It has been such a pleasure hosting a room in my apartment on the Spleet
        platform and to welcome guests. I have met some great people and made
        lifelong friendships.
      </Text>

      <Text weight={"bold"}>Prince Akinkunmi</Text>
      <Text fz={"15px"}>Homeowner</Text>
    </>
  );
};
export default TestifierBox;
