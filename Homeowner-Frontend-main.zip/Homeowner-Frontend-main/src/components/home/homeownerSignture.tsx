import ContainerLayout from "@/layouts/containerLayout";
import { Avatar, Box, Flex, Text } from "@mantine/core";
import { SignatureBox } from "../micro/signatureBox";

const UtilsBox = () => {
  return (
    <Box
      w={{
        md: "100%",
        lg: "350px",
        base: "80%",
      }}
      bg={"#F4F4F4"}
      p={"2em"}
      style={{
        borderRadius: "10px",
      }}
    >
      <Box
        w={"63px"}
        h={"63px"}
        bg={"gray"}
        style={{
          borderRadius: "50%",
        }}
      ></Box>
      <Text my={"1em"}>User Internet</Text>

      <Text>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia iusto
        est, magnam, ullam, totam esse sed accusamus explicabo nisi culpa
        cumque. Cumque error, praesentium rerum sint animi totam quaerat est!
      </Text>
    </Box>
  );
};

const HomeownerSignature = () => {
  return (
    <Box data-aos={"fade-up"}>
      <ContainerLayout>
        <Text
          fz={{
            base: "20px",
            md: "25px",
            lg: "30px",
          }}
          weight={"bold"}
          data-aos={"fade-up"}
        >
          Homeowner Signature
        </Text>

        <Text
          my={"1.5em"}
          w={{
            base: "100%",
            lg: "944px",
            md: "100px",
          }}
        >
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores
          architecto incidunt reprehenderit minus ut eius dolorem? Tenetur, id
          nam quos ea error sunt explicabo culpa molestias blanditiis itaque
          velit quis.
        </Text>

        <SignatureBox />

        <Box my={"2em"}>
          <Text
            fw={"bold"}
            fz={{
              base: "20px",
              lg: "32px",
            }}
          >
            Utilities
          </Text>

          <Flex gap={"1em"} my={"2em"} wrap={"wrap"}>
            {[1, 3, 4].map((items) => {
              return (
                <Box key={items}>
                  <UtilsBox />
                </Box>
              );
            })}
          </Flex>
        </Box>
      </ContainerLayout>
    </Box>
  );
};
export default HomeownerSignature;
