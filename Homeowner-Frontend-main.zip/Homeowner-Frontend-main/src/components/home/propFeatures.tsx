import { Box } from "@mantine/core";

const ProptechFeatures = () => {
  return <Box>
    
  </Box>;
};

export default ProptechFeatures;
