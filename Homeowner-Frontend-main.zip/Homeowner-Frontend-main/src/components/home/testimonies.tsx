import ContainerLayout from "@/layouts/containerLayout";
import { Box, Text, Flex } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
import React, { useRef, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import { Pagination } from "swiper";
import TestifierBox from "./testifierBox";
const Testimonies = () => {
  const isMobile = useMediaQuery("(max-width: 700px)");
  return (
    <Box bg={"#0f1318"} py={"8em"}>
      <ContainerLayout>
        <Flex gap={"2em"} align={"center"} justify={"space-between"}>
          <Box
            w={{
              base: "100%",
              lg: "40%",
            }}
            c={"#fff"}
          >
            <Text
              weight={"bold"}
              fz={{
                base: "20px",
                md: "30px",
                lg: "25px",
              }}
              c={"red"}
              data-aos={isMobile ? "fade-up" : "fade-right"}
            >
              {" "}
              See what clients are saying
            </Text>
            <Swiper
              pagination={true}
              modules={[Pagination]}
              className="mySwiper"
            >
              {[1, 2, 3, 4].map((items) => {
                return (
                  <>
                    <SwiperSlide>
                      <TestifierBox />
                    </SwiperSlide>
                  </>
                );
              })}
            </Swiper>
          </Box>

          <Box
            w={{
              base: "100%",
              lg: "50%",
            }}
            h={"50vh"}
            display={isMobile ? "none" : "block"}
            style={{
              backgroundImage:
                "url(https://res.cloudinary.com/dhdqt4xwu/image/upload/v1683036392/homeowners/div_2_imbhoi.svg)",
              backgroundRepeat: "no-repeat",
              backgroundSize: "contain",
              backgroundPosition: "center",
            }}
          ></Box>
        </Flex>
      </ContainerLayout>
    </Box>
  );
};
export default Testimonies;
