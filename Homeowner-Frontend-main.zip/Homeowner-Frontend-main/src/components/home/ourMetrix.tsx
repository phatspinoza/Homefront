import ContainerLayout from "@/layouts/containerLayout";
import { Box, Flex, Text } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
import { FC, useState, useEffect } from "react";

const datas = [
  {
    title: "Subscribers",
    count: 500,
  },
  {
    title: "Requests",
    count: 300,
  },
  {
    title: "Subscribers",
    count: 500,
  },
  {
    title: "Subscribers",
    count: 500,
  },
];

interface IMatrix {
  title: string;
  count: number;
}

const ShowMatrix: FC<IMatrix> = ({ title, count }) => {
  return (
    <Box
      w={{
        base: "100%",
        lg: "300px",
      }}
      //@ts-ignore
      align={"center"}
    >
      <Text
        fz={{
          lg: "30px",
          base: "28px",
        }}
      >
        {count}
      </Text>
      <Text
        fz={{
          lg: "25px",
          base: "20px",
        }}
      >
        {title}
      </Text>
    </Box>
  );
};

const Metrix = () => {
  const isMobile = useMediaQuery("(max-width: 728px)");
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.pageYOffset);
    };
    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <ContainerLayout>
      <Box my={"5em"}>
        <Text
          weight={"bold"}
          fz={{
            lg: "35px",
            base: "25px",
          }}
        >
          How we are Growing
        </Text>

        <Flex
          gap={isMobile ? "4em" : "2em"}
          my={"7em"}
          justify={"center"}
          align={"center"}
          direction={{
            lg: "row",
            md: "column",
            base: "column",
          }}
        >
          {datas.map(({ count, title }, index) => {
            const visible = index * 500 < scrollPosition;
            const currentCount = visible
              ? Math.min(count, Math.floor((scrollPosition - index * 500) / 10))
              : 0;
            return (
              <Box key={index}>
                {/* @ts-ignore */}
                <ShowMatrix title={title} count={`${currentCount} +`} />
              </Box>
            );
          })}
        </Flex>
      </Box>
    </ContainerLayout>
  );
};

export default Metrix;
