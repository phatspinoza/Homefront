import { Carousel } from "@mantine/carousel";
import { useMediaQuery } from "@mantine/hooks";
import {
  createStyles,
  Paper,
  Text,
  Title,
  Button,
  useMantineTheme,
  rem,
  Box,
} from "@mantine/core";
import ContainerLayout from "@/layouts/containerLayout";

const useStyles = createStyles((theme) => ({
  card: {
    height: rem(440),
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "flex-start",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },

  title: {
    fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    fontWeight: 900,
    color: theme.white,
    lineHeight: 1.2,
    fontSize: rem(32),
    marginTop: theme.spacing.xs,
  },

  category: {
    color: theme.white,
    opacity: 0.7,
    fontWeight: 700,
    textTransform: "uppercase",
  },
}));

interface CardProps {
  image: string;
  title: string;
  category: string;
}

function Card({ image, title, category }: CardProps) {
  const { classes } = useStyles();

  return (
    <Paper
      shadow="md"
      p="xl"
      radius="md"
      sx={{ backgroundImage: `url(${image})` }}
      className={classes.card}
      // style={{
      //   backgroundImage: "linear-gradient(181deg, #0000008a, transparent)",
      // }}
    >
      <Box>
        <Text className={classes.category} size="xs">
          {category}
        </Text>
        <Title order={3} className={classes.title}>
          {title}
        </Title>
      </Box>
    </Paper>
  );
}

const data = [
  {
    image:
      "https://res.cloudinary.com/dhdqt4xwu/image/upload/v1683120706/homeowners/kara-eads-L7EwHkq1B2s-unsplash_osegr8.jpg",
    title: "Victoria Island",
    category: "Estate",
  },
  {
    image:
      "https://res.cloudinary.com/dhdqt4xwu/image/upload/v1681839793/homeowners/francesca-tosolini-tHkJAMcO3QE-unsplash_pcpvva.jpg",
    title: "Bana Island, Beach Front",
    category: "beach",
  },
  {
    image:
      "https://res.cloudinary.com/dhdqt4xwu/image/upload/v1681839767/homeowners/francesca-tosolini-XcVm8mn7NUM-unsplash_wdy9i7.jpg",
    title: "Ikoyi Island, Lagos",
    category: "Mansion",
  },
];

export const TeamSection = () => {
  const theme = useMantineTheme();
  const mobile = useMediaQuery(`(max-width: ${theme.breakpoints.sm})`);
  const slides = data.map((item) => (
    <Carousel.Slide key={item.title}>
      <Card {...item} />
    </Carousel.Slide>
  ));

  return (
    <ContainerLayout>
      <Box my={"4em"}>
        <Text
          my={"2em"}
          weight={"bold"}
          fz={{
            lg: "33px",
            base: "25px",
          }}
        >
          Some of our Properties
        </Text>
        <Carousel
          slideSize="50%"
          breakpoints={[{ maxWidth: "sm", slideSize: "100%", slideGap: 2 }]}
          slideGap="xl"
          align="start"
          slidesToScroll={mobile ? 1 : 2}
        >
          {slides}
        </Carousel>
      </Box>
    </ContainerLayout>
  );
};
