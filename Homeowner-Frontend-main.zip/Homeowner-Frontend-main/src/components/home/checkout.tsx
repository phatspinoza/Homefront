import ContainerLayout from "@/layouts/containerLayout";
import { Text, Box, Flex } from "@mantine/core";
import ProductBox from "../essentials/productBox";
const Checkout = () => {
  return (
    <ContainerLayout>
      <Text>On Trending NOw</Text>
      <ProductBox />
    </ContainerLayout>
  );
};
export default Checkout;
