import { Box, Text } from "@mantine/core";
import Header from "../layouts/header";
import ContainerLayout from "@/layouts/containerLayout";
import Search from "../essentials/searchItems";

const HomeHero = () => {
  const styles = {
    backgroundImage:
      "url(https://res.cloudinary.com/dhdqt4xwu/image/upload/v1684416254/homeowners/istockphoto-1368613398-612x612_ps5n0g.jpg)",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
  };
  return (
    <Box h={"90vh"} style={styles}>
      <Box bg={"#000000e0"} h={"100%"}>
        <Header />

        <ContainerLayout>
          <Box
            w={{
              base: "100%",
              md: "100%",
              lg: "672px",
            }}
            mx={"auto"}
            my={"150px"}
          >
            <Text
              fz={{
                base: "30px",
                md: "30px",
                lg: "65px",
              }}
              c={"white"}
              align="center"
            >
              Freedom to Live Smart
            </Text>

            <Search />
          </Box>
        </ContainerLayout>
      </Box>
    </Box>
  );
};
export default HomeHero;
