import ContainerLayout from "@/layouts/containerLayout";
import { Accordion, Box, Text } from "@mantine/core";

const faqContents = [
  {
    title: "How does Homeowners work",
    description: "Its a real estate platform",
  },
  {
    title: "Can i pay installmentally ?",
    description: "Its a real estate platform",
  },
  {
    title: "How long can i get a Property",
    description: "Its a real estate platform",
  },
];
const Faq = () => {
  return (
    <>
      <ContainerLayout>
        <Box
          w={{
            base: "100%",
            lg: "70%",
          }}
          mx={"auto"}
        >
          <Text
            weight={"bold"}
            fz={{
              base: "30px",
              md: "30px",
              lg: "40px",
            }}
            my={"2em"}
          >
            Frequently asked question
          </Text>

          {faqContents.map((items) => {
            return (
              <>
                <Accordion variant="filled">
                  <Accordion.Item value="flexibility">
                    <Accordion.Control>{items.title}</Accordion.Control>
                    <Accordion.Panel>{items.description}</Accordion.Panel>
                  </Accordion.Item>
                </Accordion>
              </>
            );
          })}
        </Box>
      </ContainerLayout>
    </>
  );
};

export default Faq;
