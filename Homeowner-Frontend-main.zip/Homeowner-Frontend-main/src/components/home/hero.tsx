import ContainerLayout from "@/layouts/containerLayout";
import { Box, Button, Flex, Text, TextInput } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
import { BiSearch } from "react-icons/bi";
import Header from "../layouts/header";
import ButtonInterface from "../micro/buttonInterface";

const Hero = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");

  const btn = (
    <Button bg={"red"} size="lg" radius={"9999px"} mr={"3em"}>
      {isMobile ? <BiSearch /> : <BiSearch />}
    </Button>
  );

  const search = (
    <TextInput
      placeholder="Find Properties..."
      rightSection={btn}
      styles={{
        input: {
          padding: "2.5em 2em",
          borderRadius: "2em",
          background: "#1F1F1F",
          border: "none",
          color: "#fff",
        },
      }}
    />
  );
  return (
    <>
      <Box bg={""}>
        <Header />
        <ContainerLayout>
          <Flex
            my={"5em"}
            gap={"2em"}
            direction={{
              base: "column",
              lg: "row",
            }}
            align={"center"}
          >
            <Box
              w={{
                base: "100%",
                lg: "60%",
              }}
              //@ts-ignore
              align={isMobile ? "center" : "left"}
            >
              <Text
                weight={"bold"}
                fz={{
                  lg: "60px",
                  base: "25px",
                }}
              >
                The Freedom to Live Smart
              </Text>

              <Text
                my={"1em"}
                w={{
                  base: "100%",
                  lg: "70%",
                }}
                fz={{
                  lg: "20px",
                  base: "16px",
                }}
              >
                {" "}
                This is where you find your dream place to Rent, Lease and Buy{" "}
                including properties
              </Text>

              <Flex
                w={{
                  base: "100%",
                  lg: "70%",
                }}
              >
                <TextInput
                  w={"100%"}
                  type="search"
                  placeholder="Search property"
                  size="lg"
                />
                <ButtonInterface>Search</ButtonInterface>
              </Flex>
            </Box>

            <Box
              bg={"gray"}
              w={{
                base: "100%",
                lg: "50%",
              }}
              h={{
                base: "50vh",
                lg: "65vh",
              }}
              style={{
                borderRadius: "10px",
                backgroundRepeat: "no-repeat",
                backgroundPosition: "center",
                backgroundSize: "cover",
                backgroundImage:
                  "url(https://res.cloudinary.com/dhdqt4xwu/image/upload/v1681839793/homeowners/francesca-tosolini-tHkJAMcO3QE-unsplash_pcpvva.jpg)",
              }}
            ></Box>
          </Flex>
        </ContainerLayout>
      </Box>
    </>
  );
};

export default Hero;
