import ContainerLayout from "@/layouts/containerLayout";
import { Flex, Text, Box, Avatar } from "@mantine/core";
import { FC } from "react";

interface ITeamProps {
  name: string;
  src: string | null;
}

const data = [
  {
    name: "Prince Muhammed",
    src: "",
  },
  {
    name: "Prince Muhammed",
    src: "",
  },
  {
    name: "Prince Muhammed",
    src: "",
  },
];
const Team: FC<ITeamProps> = ({ name, src }) => (
  <Box
    style={{
      textAlign: "center",
      display: "flex",
      alignItems: "center",
      flexDirection: "column",
    }}
  >
    <Box
      bg={"gray"}
      w={"100px"}
      h={"100px"}
      style={{
        borderRadius: "50%",
      }}
    ></Box>
    <Text
      my={"1em"}
      weight={"bold"}
      fz={{
        base: "17px",
        lg: "19px",
      }}
      align="center"
    >
      {name}
    </Text>
  </Box>
);
const OurTeam = () => {
  return (
    <ContainerLayout>
      <Text
        fz={{
          base: "20px",
          lg: "30px",
        }}
        weight={"bold"}
      >
        Our Team
      </Text>
      <Flex
        my={"5em"}
        justify={"space-evenly"}
        wrap={"wrap"}
        direction={{
          base: "column",
          lg: "row",
        }}
        gap={"2em"}
      >
        {data.map((items, index) => {
          return (
            <Box key={index}>
              <Team src={null} name={items.name} />
            </Box>
          );
        })}
      </Flex>
    </ContainerLayout>
  );
};

export default OurTeam;
