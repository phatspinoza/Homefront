import ContainerLayout from "@/layouts/containerLayout";
import { Box, Flex, Tabs, Text } from "@mantine/core";
import { useMediaQuery } from "@mantine/hooks";
import { ReactNode, FC } from "react";
import { MdOutlineKeyboardDoubleArrowRight } from "react-icons/md";
import ButtonInterface from "../micro/buttonInterface";

interface IProps {
  title: string;
  src: string;
  children: ReactNode;
}
const DetailBox: FC<IProps> = ({ title, children, src }) => {
  const isMobile = useMediaQuery("(max-width: 768px)");
  return (
    <Flex
      my={"4em"}
      align={"center"}
      gap={"2em"}
      direction={{
        base: "column",
        lg: "row",
      }}
    >
      <Box
        w={{
          base: "100%",
          lg: "55%",
        }}
        h={"450px"}
        // bg={"#fff0f6"}
        style={{
          backgroundImage: `url(${src})`,
          backgroundRepeat: "no-repeat",
          backgroundSize: !isMobile ? "cover" : "contain",
        }}
      ></Box>
      <Box
        w={{
          base: "100%",
          lg: "55%",
        }}
      >
        <Text
          weight={"bold"}
          fz={{
            lg: "53px",
            base: "25px",
          }}
        >
          {title}
        </Text>
        <Box
          my={"1em"}
          fz={{
            base: "16px",
            lg: '"18px"',
          }}
          style={{
            lineHeight: "27px",
          }}
        >
          {children}
        </Box>

        <Flex
          justify={{
            base: "center",
            lg: "left",
          }}
        >
          {/* @ts-ignore */}
          <ButtonInterface px={"5em"}>Continue</ButtonInterface>
        </Flex>
      </Box>
    </Flex>
  );
};
const ExplanationTab = () => {
  return (
    <ContainerLayout>
      <Tabs color="teal" variant="outline" defaultValue="first" my={"5rem"}>
        <Tabs.List>
          <Tabs.Tab value="first">For Landlords</Tabs.Tab>
          <Tabs.Tab value="second" color="blue">
            For Tenants
          </Tabs.Tab>
        </Tabs.List>

        <Tabs.Panel value="first" pt="xs">
          <DetailBox
            title={"Homeowner for Landlords "}
            src="https://res.cloudinary.com/dhdqt4xwu/image/upload/v1683112142/homeowners/Group_237785_rnv5g1.svg"
          >
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis
            non possimus, ipsam fuga et magnam, delectus dolorem reiciendis
            debitis asperiores magni corrupti impedit commodi in! Ex sit
            molestias illo. Molestias?
          </DetailBox>
        </Tabs.Panel>

        <Tabs.Panel value="second" pt="xs">
          <DetailBox
            title={"Homeowner for tenants "}
            src="https://res.cloudinary.com/dhdqt4xwu/image/upload/v1683121248/homeowners/Group_237785_djrdqt.svg"
          >
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis
            non possimus, ipsam fuga et magnam, delectus dolorem reiciendis
            debitis asperiores magni corrupti impedit commodi in! Ex sit
            molestias illo. Molestias?
          </DetailBox>
        </Tabs.Panel>
      </Tabs>
    </ContainerLayout>
  );
};

export default ExplanationTab;
