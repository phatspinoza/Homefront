import FeatureBox from "@/components/home/featureBox";
import Features from "@/components/home/features";
import HomeHero from "@/components/home/homeHero";
import HomeownerSignature from "@/components/home/homeownerSignture";
import Testimonies from "@/components/home/testimonies";
import Footer from "@/components/layouts/footer";
import Header from "@/components/layouts/header";
import { Box } from "@mantine/core";
import SummaryBox from "@/components/micro/sumarryBox";
import Metrix from "@/components/home/ourMetrix";
const Homepage = () => {
  return (
    <>
      <HomeHero />
      <Features />
      <HomeownerSignature />
      <Box my={"5em"}>
        <Testimonies />
      </Box>

      <Metrix />
      <SummaryBox />
      <Footer />
    </>
  );
};

export default Homepage;
