import Loader from "@/components/essentials/loader";
import Checkout from "@/components/home/checkout";
import ExplanationTab from "@/components/home/explanationTab";
import Faq from "@/components/home/faq";
import Features from "@/components/home/features";
import Hero from "@/components/home/hero";
import Info from "@/components/home/info";
import Testimonies from "@/components/home/testimonies";
import WhyUs from "@/components/home/whyus";
import Footer from "@/components/layouts/footer";
import { useEffect, useState } from "react";
import { Box } from "@mantine/core";
import { TeamSection } from "@/components/home/team";
import OurTeam from "@/components/home/ourTeam";
const AboutUs = () => {
  const [loader, setLoader] = useState("block");

  useEffect(() => {
    setTimeout(() => setLoader("none"), 2500);
  }, []);
  return (
    <>
      <Box display={loader}>
        <Loader />
      </Box>
      <Hero />
      <WhyUs />

      {/* <Checkout /> */}
      <Info />
      <ExplanationTab />
      <TeamSection />
      <OurTeam />
      <Testimonies />

      <Faq />
      <Footer />
    </>
  );
};
export default AboutUs;
