import AboutUs from "./aboutus";

const About = () => {
  return <AboutUs />;
};

export default About;
