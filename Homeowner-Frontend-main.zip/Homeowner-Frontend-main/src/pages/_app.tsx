import "@/styles/main.scss";
import type { AppProps } from "next/app";
import { MantineProvider } from "@mantine/core";
//@ts-ignore
import AOS from "aos";
import { useEffect } from "react";
export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    AOS.init({
      duration: 1000,
    });
  }, []);
  return (
    <MantineProvider
      theme={{
        colorScheme: "light",
      }}
    >
      <Component {...pageProps} />
    </MantineProvider>
  );
}
