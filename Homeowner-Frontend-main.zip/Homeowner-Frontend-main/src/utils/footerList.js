const companyNavs = [

  {
    title: 'About',
    path: ''
  },
  {
    title: 'Blog',
    path: ''
  }, 
  {
    title: 'Contact',
    path: ''
  }


 
]

const aboutNavs = [
  {
    title: 'Find your home',
    path: ''
  },
  {
    title: 'List your space', 
    path: ''
  },
  {
    title: 'Verify Tenant', 
    path: ''
  }
]

const supportNav = [
  {
    title: 'Give us Feedback',
    path: ''
  },
  {
    title: 'Help center', 
    path: ''
  },
  {
    title: 'Live chat', 
    path: ''
  }
]

const resourceNav = [
  {
    title: 'Give us Feedback',
    path: ''
  },
  {
    title: 'Faq', 
    path: ''
  },
  {
    title: 'Blog', 
    path: ''
  }
]


export { companyNavs , aboutNavs, resourceNav,  supportNav }