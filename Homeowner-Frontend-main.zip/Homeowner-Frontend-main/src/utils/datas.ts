
import { ITestimoniesData } from "@/types/mixedTypes"

export const testimoniesData: ITestimoniesData[] = [

    {
        src: '', 
        title:"Salau Aba",
        body: `Lorem ipsum is a placeholder text commonly used in the graphic, print, 
        a filler when the actual content is not yet available. `
    }, 
    {
        src: '', 
        title:"Salau Aba",
        body: `Lorem ipsum is a placeholder text commonly used in the graphic, print, 
        a filler when the actual content is not yet available. `
    }, 
    {
        src: '', 
        title:"Salau Aba",
        body: `Lorem ipsum is a placeholder text commonly used in the graphic, print, 
        a filler when the actual content is not yet available. `
    }, 
    {
        src: '', 
        title:"Salau Aba",
        body: `Lorem ipsum is a placeholder text commonly used in the graphic, print, 
        a filler when the actual content is not yet available. `
    },


]