interface FooterNavInter {
  title: string;
  path?: string;
}

interface HeaderNavItems {
  title: string;
  path?: string;
}

export type { HeaderNavItems, FooterNavInter };
